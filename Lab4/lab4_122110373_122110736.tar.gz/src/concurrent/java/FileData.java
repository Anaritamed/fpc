public class FileData {

    public final String name;
    public final String content;

    public FileData(String name, String content) {
        this.name = name;
        this.content = content;
    }
}
